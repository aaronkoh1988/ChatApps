﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Pipes;

// Author : Aaron Koh Hsien Loong//
// Purpose of code : To design a simple chat application//
// Date : 20/8/16//
// Known bugs: A deadlock between 2 application if click start chat//

namespace ChatProgram2
{
    public partial class frmChat2 : Form
    {
        
        public frmChat2()
        {
            InitializeComponent();
        }
        NamedPipeServerStream Chatbox2 = new NamedPipeServerStream("ChatBox2");

        private void btnStartChat_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Waiting for Connection...");
            //hostPipe();
            connectPipe();
        }

        private void hostPipe()
        {
            Chatbox2.WaitForConnection();
            lbxChat.Items.Add("Connection had been Established");
        }

        private void connectPipe()
        {
            NamedPipeClientStream ChatBox1 = new NamedPipeClientStream("ChatBox1");
            ChatBox1.Connect();
            Byte[] ClientByte;
            int l;

            while (ChatBox1.IsConnected)
            {
                ClientByte = new Byte[1000];
                for (int i = 0; i < ClientByte.Length; i++)
                {
                    ClientByte[i] = 0x20;
                }

                l = Array.IndexOf(ClientByte, 0x20);
                ChatBox1.Read(ClientByte, 0, ClientByte.Length);

                string msgStr = System.Text.Encoding.GetEncoding("windows-1256").GetString(ClientByte);
                lbxChat.Items.Add(msgStr.Trim());

            } // end of while
            ChatBox1.Close();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            
        }
    }
}
