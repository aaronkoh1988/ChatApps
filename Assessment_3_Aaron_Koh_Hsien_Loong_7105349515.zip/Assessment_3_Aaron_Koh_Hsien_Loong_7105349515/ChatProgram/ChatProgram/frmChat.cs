﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Pipes;

// Author : Aaron Koh Hsien Loong//
// Purpose of code : To design a simple chat application//
// Date : 20/8/16//
// Known bugs: A deadlock between 2 application if click start chat//

namespace ChatProgram
{
    public partial class frmChat : Form
    {
        public frmChat()
        {
            InitializeComponent();
        }

        NamedPipeServerStream ChatBox1 = new NamedPipeServerStream("ChatBox1");

        private void btnStartChat_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Waiting for Connection...");
            hostPipe();
            //connectPipe();
        }

        private void connectPipe()
        {
            NamedPipeClientStream ChatBox2 = new NamedPipeClientStream("ChatBox2");
            ChatBox2.Connect();
        }

        private void hostPipe()
        {
            
            ChatBox1.WaitForConnection();
            lbxChat.Items.Add("Connection had been established.");
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            do
            {
                String msg = txtSend.Text;
                Byte[] msgByte = System.Text.Encoding.GetEncoding("windows-1256").GetBytes(msg);
                ChatBox1.Write(msgByte, 0, msg.Length);
            }
            while (true);
        }
    }
}
